import { useEffect, useRef, useState } from "react";
import videojs from "video.js";
import "video.js/dist/video-js.css";
import { Play, Pause } from "lucide-react";

export default function VideoPlayer({
  currentClip,
  currentTime,
  isPlaying,
  onPlayPause,
  onClipEnd,
  onTimeUpdate,
  clips,
  duration,
  onRequestSeek, // global timeline seek
  zoom = 1,
}) {
  const videoRef = useRef(null);
  const playerRef = useRef(null);
  const [localTime, setLocalTime] = useState(0);
  const [isPlayerReady, setIsPlayerReady] = useState(false);
  const [audioContext, setAudioContext] = useState(null);
  const safeZoom = Math.min(Math.max(zoom, 0.5), 3);

  // Refs to hold the latest callbacks/values
  const onTimeUpdateRef = useRef(onTimeUpdate);
  const onClipEndRef = useRef(onClipEnd);
  const currentClipRef = useRef(currentClip);
  const EPS_END = 0.05;

  useEffect(() => {
    onTimeUpdateRef.current = onTimeUpdate;
  }, [onTimeUpdate]);
  useEffect(() => {
    onClipEndRef.current = onClipEnd;
  }, [onClipEnd]);
  useEffect(() => {
    currentClipRef.current = currentClip;
  }, [currentClip]);

  // Initialize Video.js once
  useEffect(() => {
    if (!videoRef.current || playerRef.current) return;

    const player = videojs(videoRef.current, {
      controls: false,
      autoplay: false,
      preload: "auto",
      fluid: true,
      muted: false, // enforced below
      responsive: true,
    });

    playerRef.current = player;
    setIsPlayerReady(true);

    player.on("timeupdate", () => {
      const time = player.currentTime();
      setLocalTime(time);
      if (onTimeUpdateRef.current && currentClipRef.current) {
        onTimeUpdateRef.current(time, currentClipRef.current.id);
      }
    });

    player.on("ended", () => {
      if (onClipEndRef.current && currentClipRef.current) {
        onClipEndRef.current(currentClipRef.current.id);
      }
      // do NOT auto-seek to 0 here; we only restart on user action
    });

    player.on("error", () => {
      const err = player.error();
      if (err) console.warn("Video player error:", err);
    });

    player.on("play", () => {
      if (audioContext && audioContext.state === "suspended") {
        audioContext.resume().catch((err) => {
          console.warn("Failed to resume audio context:", err);
        });
      }
    });
  }, [audioContext]);

  // Helper: current source URL from player
  const getCurrentSourceUrl = () => {
    const p = playerRef.current;
    if (!p) return "";
    const cs = p.currentSource && p.currentSource();
    if (cs?.src) return cs.src;
    try {
      const s = p.src();
      if (typeof s === "string" && s) return s;
      if (Array.isArray(s) && s[0]?.src) return s[0].src;
      if (s?.src) return s.src;
    } catch {}
    return "";
  };

  // EFFECT A: prime next video while an image is active
  useEffect(() => {
    const player = playerRef.current;
    if (!player || !isPlayerReady || !currentClip) return;
    if (currentClip.type !== "image") return;

    const nextVideo = (clips || [])
      .filter(
        (c) => c.type === "video" && c.startTime >= (currentClip.startTime ?? 0)
      )
      .sort((a, b) => a.startTime - b.startTime)[0];

    if (!nextVideo || !nextVideo.url) return;

    const currentSourceUrl = getCurrentSourceUrl();
    if (currentSourceUrl === nextVideo.url) return;

    playerRef.current.clipId = nextVideo.id;
    player.src({ src: nextVideo.url, type: nextVideo.mimeType || "video/mp4" });

    const onReady = () => {
      player.off("loadedmetadata", onReady);
      if (!player.paused()) player.pause();
      // Apply nextVideo's playbackRate & volume to the primed tech so when played it respects settings.
      try {
        if (typeof nextVideo.playbackRate === "number") {
          // video.js API: playbackRate(rate)
          player.playbackRate(Number(nextVideo.playbackRate));
        }
        if (typeof nextVideo.volume === "number") {
          // video.js API: volume(0..1)
          player.volume(Number(nextVideo.volume));
        }
      } catch (err) {
        // fallback to underlying media element
        try {
          const mediaEl =
            playerRef.current?.tech_?.el() ||
            playerRef.current?.el()?.querySelector("video");
          if (mediaEl) {
            if (typeof nextVideo.playbackRate === "number")
              mediaEl.playbackRate = Number(nextVideo.playbackRate);
            if (typeof nextVideo.volume === "number")
              mediaEl.volume = Number(nextVideo.volume);
          }
        } catch {}
      }
    };

    if (player.readyState() >= 1) onReady();
    else player.one("loadedmetadata", onReady);
  }, [
    currentClip?.id,
    currentClip?.type,
    currentClip?.startTime,
    clips,
    isPlayerReady,
  ]);

  // EFFECT B: Load/Seek for the active clip (no reload when already primed)
  useEffect(() => {
    const player = playerRef.current;
    if (!player || !currentClip || !isPlayerReady) return;

    if (currentClip.type === "image") {
      if (!player._imgPaused) {
        if (!player.paused()) player.pause();
        player._imgPaused = true;
      }
      return;
    }

    player._imgPaused = false;

    const currentSourceUrl = getCurrentSourceUrl();
    const urlChanged =
      !!currentClip.url && currentSourceUrl !== currentClip.url;
    const seekTo = Math.max(0, currentClip.relativeTime || 0);

    if (urlChanged) {
      playerRef.current.clipId = currentClip.id;
      player.src({
        src: currentClip.url,
        type: currentClip.mimeType || "video/mp4",
      });

      const onReady = () => {
        player.off("loadedmetadata", onReady);

        // enforce mute after tech swap
        const mediaEl =
          playerRef.current?.tech_?.el() ||
          playerRef.current?.el()?.querySelector("video");
        if (mediaEl) {
          mediaEl.muted = false;
          mediaEl.defaultMuted = false;
          mediaEl.volume = 1;
          try {
            if (mediaEl.audioTracks && mediaEl.audioTracks.length) {
              for (let i = 0; i < mediaEl.audioTracks.length; i++) {
                mediaEl.audioTracks[i].enabled = false;
              }
            }
          } catch {}
        }

        // Apply per-clip playbackRate & volume here (for newly loaded clip)
        try {
          if (typeof currentClip.playbackRate === "number") {
            player.playbackRate(Number(currentClip.playbackRate));
          } else {
            // ensure default 1 if not provided
            player.playbackRate(1);
          }
        } catch (err) {
          // fallback to native element
          try {
            if (mediaEl && typeof currentClip.playbackRate === "number") {
              mediaEl.playbackRate = Number(currentClip.playbackRate);
            }
          } catch {}
        }

        try {
          if (typeof currentClip.volume === "number") {
            player.volume(Number(currentClip.volume));
          } else {
            player.volume(1);
            if (mediaEl) mediaEl.volume = 1;
          }
        } catch (err) {
          try {
            if (mediaEl && typeof currentClip.volume === "number") {
              mediaEl.volume = Number(currentClip.volume);
            }
          } catch {}
        }

        if (Math.abs((player.currentTime() ?? 0) - seekTo) > 0.02) {
          player.currentTime(seekTo);
        }
        if (isPlaying) {
          const p = player.play();
          if (p?.catch) p.catch(() => {});
        }
      };

      if (player.readyState() >= 1) onReady();
      else player.one("loadedmetadata", onReady);
    } else {
      const drift = Math.abs((player.currentTime() ?? 0) - seekTo);
      if (drift > 0.1) player.currentTime(seekTo);

      // if clip already loaded, ensure its playbackRate & volume are enforced
      try {
        if (typeof currentClip.playbackRate === "number") {
          player.playbackRate(Number(currentClip.playbackRate));
        }
      } catch (err) {
        try {
          const mediaEl =
            playerRef.current?.tech_?.el() ||
            playerRef.current?.el()?.querySelector("video");
          if (mediaEl && typeof currentClip.playbackRate === "number")
            mediaEl.playbackRate = Number(currentClip.playbackRate);
        } catch {}
      }

      try {
        if (typeof currentClip.volume === "number") {
          player.volume(Number(currentClip.volume));
          try {
            const mediaEl =
              playerRef.current?.tech_?.el() ||
              playerRef.current?.el()?.querySelector("video");
            if (mediaEl) mediaEl.volume = Number(currentClip.volume);
          } catch {}
        }
      } catch {}

      if (isPlaying) {
        if (player.paused()) {
          const p = player.play();
          if (p?.catch) p.catch(() => {});
        }
      } else {
        if (!player.paused()) player.pause();
      }

      if (playerRef.current.clipId !== currentClip.id) {
        playerRef.current.clipId = currentClip.id;
      }
    }
  }, [
    currentClip?.url,
    currentClip?.relativeTime,
    currentClip?.id,
    currentClip?.mimeType,
    isPlayerReady,
    isPlaying,
    // note: we intentionally do NOT add currentClip.playbackRate/currentClip.volume as deps here
    // so we don't duplicate effects — the dedicated effect below handles runtime changes.
  ]);

  // EFFECT: respond to runtime changes to playbackRate or volume while clip is already loaded
  useEffect(() => {
    const player = playerRef.current;
    if (!player || !isPlayerReady || !currentClip) return;

    // Only apply if the currently loaded clip matches the currentClip
    const loadedSrc = getCurrentSourceUrl();
    if (!loadedSrc || playerRef.current.clipId !== currentClip.id) {
      return;
    }

    // Apply playbackRate if provided
    if (typeof currentClip.playbackRate === "number") {
      try {
        player.playbackRate(Number(currentClip.playbackRate));
      } catch (err) {
        try {
          const mediaEl =
            playerRef.current?.tech_?.el() ||
            playerRef.current?.el()?.querySelector("video");
          if (mediaEl) mediaEl.playbackRate = Number(currentClip.playbackRate);
        } catch {}
      }
    }

    // Apply volume if provided (0..1)
    if (typeof currentClip.volume === "number") {
      try {
        player.volume(Number(currentClip.volume));
      } catch (err) {
        try {
          const mediaEl =
            playerRef.current?.tech_?.el() ||
            playerRef.current?.el()?.querySelector("video");
          if (mediaEl) mediaEl.volume = Number(currentClip.volume);
        } catch {}
      }
    }
  }, [currentClip?.playbackRate, currentClip?.volume, isPlayerReady, currentClip?.id]);

  /** Enforce full mute on the real media element */
  useEffect(() => {
    if (!playerRef.current || !isPlayerReady) return;
    let mediaEl = null;
    try {
      mediaEl =
        playerRef.current.tech_?.el() ||
        playerRef.current.el()?.querySelector("video");
    } catch {}
    if (!mediaEl) return;
    mediaEl.muted = false;
    mediaEl.defaultMuted = false;
    mediaEl.volume = 1;
    try {
      if (mediaEl.audioTracks && mediaEl.audioTracks.length) {
        for (let i = 0; i < mediaEl.audioTracks.length; i++) {
          mediaEl.audioTracks[i].enabled = false;
        }
      }
    } catch {}
  }, [isPlayerReady]);

  /** Pause when not on a video */
  useEffect(() => {
    if (!playerRef.current || !isPlayerReady) return;
    const isVideo = currentClip?.type === "video";
    const player = playerRef.current;
    if (!isVideo) {
      try {
        if (!player.paused()) player.pause();
      } catch {}
    }
  }, [currentClip?.type, isPlayerReady]);

  // Manual play toggle
  const handleManualPlay = () => {
    if (!playerRef.current) {
      onPlayPause();
      return;
    }

    const atEnd =
      typeof duration === "number" &&
      typeof currentTime === "number" &&
      currentTime >= duration - EPS_END;

    if (atEnd) {
      // ask parent to move GLOBAL timeline to 0
      if (onRequestSeek) onRequestSeek(0);

      // also reset the HTML5 player if we're on a video
      try {
        if (currentClip?.type === "video") playerRef.current.currentTime(0);
      } catch {}
    }

    onPlayPause();
  };

  // Format mm:ss
  const formatTime = (sec) => {
    const mins = Math.floor(sec / 60);
    const secs = Math.floor(sec % 60);
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  // Cleanup
  useEffect(() => {
    return () => {
      if (playerRef.current) {
        try {
          playerRef.current.dispose();
        } catch {}
        playerRef.current = null;
      }
    };
  }, []);

  const displayTime =
    typeof duration === "number" &&
    typeof currentTime === "number" &&
    currentTime >= duration - 0.05
      ? duration 
      : currentTime;

  return (
    <div className="flex flex-col items-center w-full justify-center bg-white rounded-lg p-4 h-[60vh]">
      {/* Video Display */}
      <div className="relative w-full max-w-4xl h-[80%] rounded-lg overflow-hidden mb-2 flex items-center justify-center bg-black" style={{height: 392, width: 730}}>
        <div
          className="w-full h-full flex items-center justify-center"
          style={{ transform: `scale(${safeZoom})`, transformOrigin: "center" }}
        >
          {/* Keep video element mounted for Video.js stability */}
          <video
            ref={videoRef}
            className="video-js vjs-default-skin w-full h-full object-contain absolute inset-0"
            playsInline
            preload="auto"
            muted
          />

          {/* Image overlay shown when current clip is an image */}
          {currentClip?.type === "image" && (
            <img
              src={currentClip.url}
              alt={currentClip.fileName || "image"}
              className="absolute inset-0 w-full h-full object-contain z-10 transition-opacity duration-500"
              style={{ backgroundColor: "black" }}
            />
          )}
        </div>
      </div>

      {/* Controls */}
      <div className="flex items-center gap-4 w-full max-w-4xl justify-center">
        <span className="text-black font-mono text-sm">
          {formatTime(displayTime || 0)}
        </span>

        <button
          onClick={handleManualPlay}
          className="w-12 h-12 bg-indigo-600 rounded-full flex items-center justify-center hover:bg-indigo-700 transition-colors shadow-lg"
          disabled={!isPlayerReady}
        >
          {isPlaying ? (
            <Pause className="w-6 h-6 text-white" />
          ) : (
            <Play className="w-6 h-6 text-white ml-1" />
          )}
        </button>

        <span className="text-black font-mono text-sm">
          {formatTime(duration)}
        </span>
      </div>
    </div>
  );
}
